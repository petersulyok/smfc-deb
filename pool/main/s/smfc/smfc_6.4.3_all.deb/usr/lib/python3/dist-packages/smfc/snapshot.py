#
#   snapshot.py (C) 2020-2026, Peter Sulyok
#   smfc package: Supermicro fan control for Linux (home) servers.
#   build_snapshot(): produce the live-state dict consumed by smfc-client and the Prometheus exporter.
#
import time
from importlib.metadata import version
from typing import TYPE_CHECKING, Any, Dict, List

from smfc.constfc import ConstFc
from smfc.cpufc import CpuFc
from smfc.gpufc import GpuFc
from smfc.hdfc import HdFc
from smfc.npufc import NpuFc
from smfc.config import PlatformName
from smfc.ipmi import Ipmi
from smfc.nvmefc import NvmeFc
from smfc.pcifc import PciFc

if TYPE_CHECKING:  # pragma: no cover
    from smfc.service import Service


SNAPSHOT_SCHEMA_VERSION: int = 1


def _controller_type_label(controller) -> str:  # pylint: disable=too-many-return-statements
    """Map a controller instance to its short type label used in the JSON schema and metric labels.

    The Service.controllers list is closed: it only holds CpuFc, HdFc, NvmeFc, GpuFc, NpuFc, PciFc, ConstFc.
    """
    if isinstance(controller, ConstFc):
        return "const"
    if isinstance(controller, HdFc):
        return "hd"
    if isinstance(controller, NvmeFc):
        return "nvme"
    if isinstance(controller, GpuFc):
        return "gpu"
    if isinstance(controller, NpuFc):
        return "npu"
    if isinstance(controller, PciFc):
        return "pci"
    assert isinstance(controller, CpuFc), f"unknown controller type: {type(controller).__name__}"
    return "cpu"


def _build_controller_entry(controller) -> Dict[str, Any]:
    """Build the JSON dict for a single controller (FanController subclass or ConstFc)."""
    type_label = _controller_type_label(controller)
    cfg = controller.config
    entry: Dict[str, Any] = {
        "section": cfg.section,
        "type": type_label,
        "enabled": bool(cfg.enabled),
        "ipmi_zones": list(cfg.ipmi_zone),
        "polling": float(cfg.polling),
        "deferred_apply": bool(getattr(controller, "deferred_apply", False)),
        "last_temp_c": float(getattr(controller, "last_temp", 0.0)),
        "last_level_pct": int(getattr(controller, "last_level", 0)),
    }
    if type_label == "const":
        # ConstFc has no underlying device set; expose its target level explicitly.
        entry["device_count"] = 0
        entry["target_level_pct"] = int(cfg.level)
        # Static steering window: CONST drives a single fixed level and has no temperature window.
        entry["level_min_pct"] = int(cfg.level)
        entry["level_max_pct"] = int(cfg.level)
    else:
        entry["device_count"] = int(getattr(controller, "count", 0))
        # Static steering window: [T_min, T_max] mapped onto [L_min, L_max]. When
        # `control_function` is configured, those legacy min/max keys are IGNORED at runtime
        # (the LUT is built from the breakpoints), so reporting them here would be misleading.
        # Surface the curve's actual envelope instead, taken from the first and last pair —
        # this keeps the band-colour logic in smfc-client (which keys off these fields) honest
        # and lets the verbose Window: line match what the curve is actually doing.
        curve = list(getattr(cfg, "control_function", []) or [])
        if curve:
            first_t, first_l = curve[0]
            last_t, last_l = curve[-1]
            entry["temp_min_c"] = float(first_t)
            entry["temp_max_c"] = float(last_t)
            entry["level_min_pct"] = int(first_l)
            entry["level_max_pct"] = int(last_l)
        else:
            entry["temp_min_c"] = float(cfg.min_temp)
            entry["temp_max_c"] = float(cfg.max_temp)
            entry["level_min_pct"] = int(cfg.min_level)
            entry["level_max_pct"] = int(cfg.max_level)
        # The raw breakpoints — empty list when no curve is configured. smfc-client renders this
        # as a `Curve:` line under `Window:` so the user sees the active LUT directly.
        entry["control_function"] = [[int(t), int(l)] for t, l in curve]
        # Per-device temperature readings cached by the loop's last get_temp() call. Names come
        # from the controller (HD/NVMe expose configured paths; CPU/GPU synthesize ordinal labels).
        # When the loop hasn't run yet temps may be shorter than names — pad with 0.0 so the
        # array length always matches device_count.
        # "read_errors" is the current consecutive failed-read streak of the device (see error_tolerance):
        # 0 while the device is healthy, so a non-zero value means the reported temp_c is a reused,
        # stale reading. "read_errors_total" is the monotonic lifetime count of failed reads of the
        # device, which a successful read does NOT reset.
        names = list(controller.device_names())
        temps = list(getattr(controller, "last_per_device_temps", []) or [])
        errors = list(getattr(controller, "_temp_read_errors", []) or [])
        errors_total = list(getattr(controller, "_temp_read_errors_total", []) or [])
        entry["devices"] = [
            {"name": names[i],
             "temp_c": float(temps[i]) if i < len(temps) else 0.0,
             "read_errors": int(errors[i]) if i < len(errors) else 0,
             "read_errors_total": int(errors_total[i]) if i < len(errors_total) else 0}
            for i in range(len(names))
        ]

    if isinstance(controller, HdFc):
        # Per-disk paths live in entry["devices"][i]["name"] (built above); the standby block
        # below indexes states[i] positionally against that list.
        if cfg.standby_guard_enabled and controller.count > 1:
            states = list(getattr(controller, "standby_array_states", []))
            entry["standby_guard"] = {
                "enabled": True,
                "limit": int(cfg.standby_hd_limit),
                "states": states,
                "array_state": "".join("S" if s else "A" for s in states),
                "standby_count": sum(1 for s in states if s),
            }
        else:
            entry["standby_guard"] = {"enabled": False}

    return entry


def build_snapshot(service: "Service") -> Dict[str, Any]:
    """Build a JSON-serializable snapshot of the live smfc service state.

    The function reads only already-cached state on the Service, its controllers, and the Ipmi
    instance. It issues no subprocesses (no ipmitool, no smartctl) and is safe to call from a
    non-loop thread (e.g. an HTTP request handler) without any synchronization primitive — see
    "Concurrency & freshness" in CLIENT_SERVER.md for the design rationale.

    Args:
        service (Service): the running Service instance.

    Returns:
        dict: JSON-serializable snapshot dict with schema version SNAPSHOT_SCHEMA_VERSION.
    """
    ipmi: Ipmi = service.ipmi
    now = time.time()

    last_fan_mode = int(service.last_fan_mode)
    last_fan_mode_at = float(service.last_fan_mode_at)
    age_s = max(0.0, time.monotonic() - last_fan_mode_at)

    controllers_section: List[Dict[str, Any]] = [
        _build_controller_entry(fc) for fc in service.controllers
    ]

    # Defensive copy: applied_levels is mutated by the main loop on every iteration.
    applied_levels = dict(service.applied_levels)
    zones_section: Dict[str, Dict[str, int]] = {
        str(zone): {"applied_level_pct": int(level)}
        for zone, level in sorted(applied_levels.items())
    }

    return {
        "version": SNAPSHOT_SCHEMA_VERSION,
        "generated_at": now,
        "smfc_version": version("smfc"),
        "start_time": float(getattr(service, "start_time", 0.0)),
        "fan_mode_enforced_count": int(getattr(service, "fan_mode_enforced_count", 0)),
        "bmc": {
            "manufacturer_name": ipmi.bmc_manufacturer_name,
            "manufacturer_id": int(ipmi.bmc_manufacturer_id),
            "product_name": ipmi.bmc_product_name,
            "product_id": int(ipmi.bmc_product_id),
            "firmware_rev": ipmi.bmc_firmware_rev,
            "ipmi_version": ipmi.bmc_ipmi_version,
            "platform": (f"{ipmi.config.platform_name} -> {type(ipmi.platform).__name__}"
                         if ipmi.config.platform_name == PlatformName.AUTO
                         else str(ipmi.config.platform_name)),
        },
        "fan_mode": {
            "id": last_fan_mode,
            "name": Ipmi.get_fan_mode_name(last_fan_mode),
            "age_s": round(age_s, 3),
            "enforce_fan_mode": bool(ipmi.config.enforce_fan_mode),
            # False on the platforms where FULL fan mode is not the controlled state, so a reader knows
            # the mode above is the fallback curve rather than the state smfc holds.
            "enforces_full_mode": bool(getattr(ipmi.platform, "ENFORCES_FULL_MODE", True)),
            # The control verdict of the last check. It means the same thing on every platform - FULL fan
            # mode where that is the controlled state, the per-zone manual latch on X14/H14 - so it is the
            # one field a reader can act on without knowing which board this is.
            "control_held": bool(getattr(service, "last_control_held", True)),
            "control_detail": str(getattr(service, "last_control_detail", "")),
        },
        "fan_controllers": controllers_section,
        "zones": zones_section,
    }


# End.
