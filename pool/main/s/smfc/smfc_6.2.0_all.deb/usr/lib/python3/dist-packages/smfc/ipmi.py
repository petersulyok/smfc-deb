#
#   ipmi.py (C) 2020-2026, Peter Sulyok
#   smfc package: Supermicro fan control for Linux (home) servers.
#   smfc.Ipmi() class implementation.
#
import subprocess
import time
from typing import List
from smfc.log import Log
from smfc.platform import FanMode, Platform
from smfc.platform_factory import create_platform
from smfc.config import IpmiConfig, Config, PlatformName


class Ipmi:
    """IPMI interface class can set/get IPMI fan mode, and can set IPMI fan level using ipmitool."""

    config: IpmiConfig              # Configuration reference
    log: Log                        # Reference to a Log class instance
    sudo: bool                      # Use `sudo` command for `ipmitool` command
    bmc_device_id: int              # BMC device ID
    bmc_device_rev: int             # BMC device revision
    bmc_firmware_rev: str           # BMC firmware revision
    bmc_ipmi_version: str           # BMC IPMI version
    bmc_manufacturer_id: int        # BMC manufacturer ID
    bmc_manufacturer_name: str      # BMC manufacturer name
    bmc_product_id: int             # BMC product ID
    bmc_product_name: str           # BMC product name
    platform: Platform              # Platform implementation for fan control

    # Backward-compatible fan mode constants (use FanMode enum for new code):
    STANDARD_MODE: int = FanMode.STANDARD
    FULL_MODE: int = FanMode.FULL
    OPTIMAL_MODE: int = FanMode.OPTIMAL
    PUE_MODE: int = FanMode.PUE
    HEAVY_IO_MODE: int = FanMode.HEAVY_IO

    # Constant values for IPMI fan zones:
    CPU_ZONE: int = 0
    HD_ZONE: int = 1

    # Constant values for the results of IPMI operations:
    SUCCESS: int = 0
    ERROR: int = -1

    # Timeout value for BMC initialization (seconds). A real `mc reset cold` on an X11SCH-LN4F takes
    # ~102 s (≈30 s interface-down + ≈69 s sensors `ns`) before the fan subsystem settles; 180 s leaves
    # headroom for a no-overlap reset while costing nothing on the happy path (the gate exits as soon as
    # the fans report live data).
    BMC_INIT_TIMEOUT: float = 180.0

    def __init__(self, log: Log, cfg: IpmiConfig, sudo: bool, *,
                 in_client: bool = False, bmc_init_timeout: float = BMC_INIT_TIMEOUT) -> None:
        """Initialize the Ipmi class with a log class and with a configuration.
        Args:
            log (Log): a Log class instance
            cfg (IpmiConfig): IPMI configuration
            sudo (bool): sudo flag
            in_client (bool): if True, do not switch the BMC into manual fan mode (read-only consumers
                              like smfc-client should set this to avoid mutating BMC state)
            bmc_init_timeout (float): override for the BMC-not-ready retry timeout (seconds);
                                      defaults to Ipmi.BMC_INIT_TIMEOUT (180 s); pass 0 to disable retries
        Raises:
            ValueError: invalid input parameters
            FileNotFoundError: ipmitool not found
            RuntimeError: ipmitool execution error
        """
        # Store config reference
        self.config = cfg
        self.log = log
        self.sudo = sudo

        # Validate configuration
        # Check 1: fan_mode_delay must be positive.
        if cfg.fan_mode_delay < 0:
            raise ValueError(f"Negative fan_mode_delay= parameter ({cfg.fan_mode_delay})")
        # Check 2: fan_level_delay must be positive.
        if cfg.fan_level_delay < 0:
            raise ValueError(f"Negative fan_level_delay= parameter ({cfg.fan_level_delay})")
        # Check 3: wait until the BMC is ready. Two conditions must hold, because after a cold boot the
        # IPMI command interface answers well before the fan subsystem has settled:
        #   (a) `sdr` executes successfully (rc=0)  -> the IPMI command interface is up;
        #   (b) a fan sensor reports live data       -> the fan subsystem has settled.
        # During the (a)-but-not-(b) window (up to ~2 minutes on a cold BMC) every sensor reads
        # `disabled`/`no reading` with state `ns`, and fan-level writes are silently forced to 100%.
        # Starting the control loop then leaves a low-polling zone stuck at 100% until its next poll.
        # The read-only `sdr` poll waits this out without touching the fans (a write-readback probe could
        # itself be clobbered mid-window; a fixed sleep is fragile). Read-only clients skip (b) so they
        # never block on a cold BMC. Both conditions share the 180 second budget in 5 second steps.
        bmc_timeout = 0.0
        while True:
            try:
                # May raise FileNotFoundError if ipmitool is not found.
                r = self._exec_ipmitool(["sdr"])
            except RuntimeError as e:
                # In case of ipmitool error we try to wait BMC initialization in maximum 180 seconds
                # (in 5 seconds steps), otherwise reraise the exception.
                if "ipmitool" in e.args[0]:
                    self.log.msg(Log.LOG_INFO, "BMC is not ready, waiting 5 seconds.")
                    time.sleep(5)
                    bmc_timeout += 5
                    if bmc_timeout < bmc_init_timeout:
                        continue
                raise
            # (a) holds (no exception). Now wait for (b): the fan subsystem to settle. The except branch
            # above never falls through here (it either re-raises or `continue`s). Clients skip (b).
            if in_client or self._fan_sensors_ready(r.stdout):
                break
            if bmc_timeout >= bmc_init_timeout:
                self.log.msg(Log.LOG_INFO, "BMC fan sensors still not ready after timeout, continuing.")
                break
            self.log.msg(Log.LOG_INFO, "BMC fan sensors are not ready, waiting 5 seconds.")
            time.sleep(5)
            bmc_timeout += 5

        # Retrieve and parse BMC information.
        r = self._exec_ipmitool(["bmc", "info"])
        fields: dict = {}
        for line in r.stdout.splitlines():
            if ":" in line:
                key, _, value = line.partition(":")
                fields[key.strip()] = value.strip()
        try:
            self.bmc_device_id = int(fields["Device ID"])
            self.bmc_device_rev = int(fields["Device Revision"])
            self.bmc_firmware_rev = fields["Firmware Revision"]
            self.bmc_ipmi_version = fields["IPMI Version"]
            self.bmc_manufacturer_id = int(fields["Manufacturer ID"])
            self.bmc_manufacturer_name = fields["Manufacturer Name"]
            self.bmc_product_id = int(fields["Product ID"].split()[0])
            self.bmc_product_name = fields["Product Name"]
        except (KeyError, ValueError, IndexError) as e:
            raise RuntimeError(f"Cannot parse BMC info: {e}") from e

        # Initialize platform-specific fan control.
        platform_name = self.config.platform_name
        if platform_name == PlatformName.AUTO:
            platform_name = self.bmc_product_name
        self.platform = create_platform(platform_name, self._exec_ipmitool)
        if not in_client:
            self.platform.start()

        # Print the configuration out at CONFIG log level.
        if self.log.log_level >= Log.LOG_CONFIG:
            self.log.msg(Log.LOG_CONFIG, "Ipmi module was initialized with:")
            self.log.msg(Log.LOG_CONFIG, f"   {Config.CV_IPMI_COMMAND} = {self.config.command}")
            self.log.msg(Log.LOG_CONFIG, f"   {Config.CV_IPMI_FAN_MODE_DELAY} = {self.config.fan_mode_delay}")
            self.log.msg(Log.LOG_CONFIG, f"   {Config.CV_IPMI_FAN_LEVEL_DELAY} = {self.config.fan_level_delay}")
            self.log.msg(Log.LOG_CONFIG, f"   {Config.CV_IPMI_REMOTE_PARAMETERS} = {self.config.remote_parameters}")
            platform_suffix = f" -> {type(self.platform).__name__}" \
                if self.config.platform_name == PlatformName.AUTO else ""
            self.log.msg(Log.LOG_CONFIG, f"   {Config.CV_IPMI_PLATFORM_NAME} = "
                                         f"{self.config.platform_name}{platform_suffix}")
            self.log.msg(Log.LOG_CONFIG, f"   {Config.CV_IPMI_ENFORCE_FAN_MODE} = {self.config.enforce_fan_mode}")
            exit_level_suffix = " (fan levels are left unchanged at exit)" \
                if self.config.exit_level == Config.EXIT_LEVEL_NONE else ""
            self.log.msg(Log.LOG_CONFIG, f"   {Config.CV_IPMI_EXIT_LEVEL} = "
                                         f"{self.config.exit_level}{exit_level_suffix}")
            self.log.msg(Log.LOG_CONFIG, "BMC information:")
            self.log.msg(Log.LOG_CONFIG, f"   manufacturer name (id) = {self.bmc_manufacturer_name} "
                                         f"({self.bmc_manufacturer_id})")
            self.log.msg(Log.LOG_CONFIG, f"   product name (id) = {self.bmc_product_name} ({self.bmc_product_id})")
            self.log.msg(Log.LOG_CONFIG, f"   IPMI version = {self.bmc_ipmi_version}")
            self.log.msg(Log.LOG_CONFIG, f"   firmware revision = {self.bmc_firmware_rev}")

    @staticmethod
    def _fan_sensors_ready(sdr_output: str) -> bool:
        """Return True if the BMC fan sensors report live data in `ipmitool sdr` output.

        After a cold boot `sdr` returns rc=0 while every sensor still reads `disabled`/`no reading`
        with state `ns` and fan-level writes are silently forced to 100%. A fan sensor reporting a
        live reading (any state other than `ns`, e.g. `500 RPM | ok`) marks the fan subsystem as
        settled. At least one fan sensor is required so that an unpopulated header that stays `ns`
        forever does not force us to wait for the full timeout.
        Args:
            sdr_output (str): stdout of `ipmitool sdr`
        Returns:
            bool: True if at least one fan sensor reports live data
        """
        for line in sdr_output.splitlines():
            fields = [f.strip() for f in line.split("|")]
            if len(fields) < 3:
                continue
            name, state = fields[0], fields[2]
            if name.upper().startswith("FAN") and state.lower() != "ns":
                return True
        return False

    def _exec_ipmitool(self, args: List[str]) -> subprocess.CompletedProcess:
        """Execute `ipmitool` command.
        Args:
            args (List[str]): command line parameters
        Returns:
            subprocess.CompletedProcess: result of the executed subprocess
        Raises:
            FileNotFoundError: ipmitool cannot be found
            RuntimeError: ipmitool execution problem (e.g. non-root user, incompatible IPMI system/motherboard)
        """
        r: subprocess.CompletedProcess  # result of the executed process
        arguments: List[str]  # Command arguments

        # Construct command line parameters.
        arguments = []
        # Add `sudo` if needed.
        if self.sudo:
            arguments.append("sudo")
        # Add `ipmitool` path.
        arguments.append(self.config.command)
        # Add remote parameters if needed.
        if self.config.remote_parameters:
            arguments.extend(self.config.remote_parameters.split())
        # Add additional command line parameters from caller.
        arguments.extend(args)
        if hasattr(self, "log") and self.log.log_level >= Log.LOG_DEBUG:
            self.log.msg(Log.LOG_DEBUG, f"ipmitool exec: {' '.join(arguments)}")
        # May raise FileNotFoundError if ipmitool is not found.
        r = subprocess.run(arguments, check=False, capture_output=True, text=True)
        if hasattr(self, "log") and self.log.log_level >= Log.LOG_DEBUG:
            self.log.msg(Log.LOG_DEBUG, f"ipmitool result: rc={r.returncode} stdout='{r.stdout.strip()}'")
        # Check error code.
        if r.returncode != 0:
            if self.sudo and "sudo" in r.stderr:
                raise RuntimeError(f"sudo error ({r.returncode}): {r.stderr}.")
            raise RuntimeError(f"ipmitool error ({r.returncode}): {r.stderr}.")
        return r

    def get_fan_mode(self) -> int:
        """Get the current IPMI fan mode.
        Returns:
            int: fan mode (FanMode.STANDARD, FanMode.FULL, FanMode.OPTIMAL, FanMode.PUE, FanMode.HEAVY_IO)
        Raises:
            FileNotFoundError: ipmitool cannot be found
            RuntimeError: ipmitool execution problem (e.g. non-root user, incompatible IPMI system/motherboard)
            ValueError: output of the ipmitool cannot be interpreted/converted
        """
        return self.platform.get_fan_mode()

    @staticmethod
    def get_fan_mode_name(mode: int) -> str:
        """Get the name of the specified IPMI fan mode.
        Args:
            mode (int): fan mode
        Returns:
            str: name of the fan mode ('UNKNOWN', 'STANDARD', 'FULL', 'OPTIMAL', 'PUE', 'HEAVY IO')
        """
        fan_mode_name: str  # Name of the fan mode

        fan_mode_name = "UNKNOWN"
        if mode == FanMode.STANDARD:
            fan_mode_name = "STANDARD"
        elif mode == FanMode.FULL:
            fan_mode_name = "FULL"
        elif mode == FanMode.OPTIMAL:
            fan_mode_name = "OPTIMAL"
        elif mode == FanMode.PUE:
            fan_mode_name = "PUE"
        elif mode == FanMode.HEAVY_IO:
            fan_mode_name = "HEAVY IO"
        return fan_mode_name

    def set_fan_mode(self, mode: int) -> None:
        """Set the IPMI fan mode.
        Args:
            mode (int): fan mode (FanMode.STANDARD, FanMode.FULL, FanMode.OPTIMAL, FanMode.PUE, FanMode.HEAVY_IO)
        Raises:
            ValueError: invalid input parameter
            FileNotFoundError: ipmitool command cannot be found
            RuntimeError: ipmitool execution problem (e.g. non-root user, incompatible IPMI system/motherboard)
        """
        if hasattr(self, "log") and self.log.log_level >= Log.LOG_DEBUG:
            self.log.msg(Log.LOG_DEBUG, f"Setting fan mode to {self.get_fan_mode_name(mode)} ({mode})")
        self.platform.set_fan_mode(mode)
        # Give time for IPMI system/fans to apply changes in the new fan mode.
        time.sleep(self.config.fan_mode_delay)

    def set_fan_level(self, zone: int, level: int) -> None:
        """Set the fan level in the specified IPMI zone.
        Args:
            zone (int): IPMI zone
            level (int): fan level in % (0-100)
        Raises:
            ValueError: invalid input parameter
            FileNotFoundError: ipmitool command cannot be found
            RuntimeError: ipmitool execution problem (e.g. non-root user, incompatible IPMI system/motherboard)
        """
        if hasattr(self, "log") and self.log.log_level >= Log.LOG_DEBUG:
            self.log.msg(Log.LOG_DEBUG, f"Setting fan level: zone={zone} level={level}%")
        self.platform.set_fan_level(zone, level)
        # Give time for IPMI and fans to spin up/down.
        time.sleep(self.config.fan_level_delay)

    def set_multiple_fan_levels(self, zone_list: List[int], level: int) -> None:
        """Set the fan level in multiple IPMI zones.
        Args:
            zone_list (List[int]): List of IPMI zones
            level (int): fan level in % (0-100)
        Raises:
            ValueError: invalid input parameter
            FileNotFoundError: ipmitool command cannot be found
            RuntimeError: ipmitool execution problem (e.g. non-root user, incompatible IPMI system/motherboard)
        """
        self.platform.set_multiple_fan_levels(zone_list, level)
        # Give time for IPMI and fans to spin up/down.
        time.sleep(self.config.fan_level_delay)

    def get_fan_level(self, zone: int) -> int:
        """Get the current fan level in a specific IPMI zone.
        Args:
            zone (int): fan zone (CPU_ZONE, HD_ZONE)
        Returns:
            int: fan level in % (0-100)
        Raises:
            ValueError: invalid input parameter
            FileNotFoundError: ipmitool command cannot be found
            RuntimeError: ipmitool execution problem (e.g. non-root user, incompatible IPMI system/motherboard)
        """
        return self.platform.get_fan_level(zone)


# End.
