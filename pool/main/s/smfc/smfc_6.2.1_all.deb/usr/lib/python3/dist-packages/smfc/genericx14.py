#
#   genericx14.py (C) 2026, Peter Sulyok
#   smfc package: Supermicro fan control for Linux (home) servers.
#   Platform implementation for Supermicro X14 motherboards.
#
from typing import List

from smfc.platform import FanMode, Platform, validate_input_range


class GenericX14Platform(Platform):
    """Platform implementation for Supermicro X14 motherboards.

    The X14 BMC (OpenBMC based) uses different IPMI raw commands from the older platforms:
    - fan duty cycle control uses 0x30 0x70 0x88 (instead of 0x30 0x70 0x66),
    - manual mode must be enabled per zone via the OEM command 0x2c 0x04 0xcf 0xc2,
    - the duty cycle is a percentage (0x00-0x64), not the 0-255 scale,
    - extended fan modes 0x00-0x0B are supported.
    """

    FANCTL_COUNT: int = 6           # Number of fan zones (0-5)
    valid_fan_modes: List[int] = [
        FanMode.STANDARD, FanMode.FULL, FanMode.OPTIMAL, FanMode.PUE, FanMode.HEAVY_IO,
        0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B,
    ]

    def start(self) -> None:
        """Enable manual fan control for all zones so the BMC stops overriding the PWM values."""
        # Enable manual mode for all zones so the BMC stops overriding the PWM values. Note that this latches
        # manual mode on every zone the hardware has, while end() applies the exit level only to the configured
        # zones - end() releases manual mode for all zones again, so nothing is left latched.
        # OEM command (IANA 0x0000C2CF): 0x2c 0x04 0xcf 0xc2 0x00 <zone> 0x01
        for zone in range(self.FANCTL_COUNT):
            self._exec(["raw", "0x2c", "0x04", "0xcf", "0xc2", "0x00", f"0x{zone:02x}", "0x01"])

    def end(self, zones: List[int], level: int) -> None:
        """Apply the exit fan level to the configured zones, then disable manual fan control for all zones,
        restoring automatic BMC fan control.

        This platform behaves differently from the others: manual mode is an explicit OEM state that would stay
        latched forever if it were not released, leaving every zone frozen at the exit level with nothing
        regulating it. Releasing it hands the fans back to the BMC, so the exit level is only a transition here
        - within seconds the BMC applies its own curve. Note that the BMC regulates on CPU and system sensors
        only, so drive temperatures are not part of that loop.
        """
        # Apply the exit level first: releasing manual mode first would hand control to the BMC and make the
        # level write a no-op.
        self.set_multiple_fan_levels(zones, level)
        # Disable manual mode for all zones, restoring automatic BMC fan control.
        # OEM command (IANA 0x0000C2CF): 0x2c 0x04 0xcf 0xc2 0x00 <zone> 0x00
        for zone in range(self.FANCTL_COUNT):
            self._exec(["raw", "0x2c", "0x04", "0xcf", "0xc2", "0x00", f"0x{zone:02x}", "0x00"])

    def get_fan_mode(self) -> int:
        """Return the current IPMI fan mode."""
        r = self._exec(["raw", "0x30", "0x45", "0x00"])
        return int(r.stdout)

    def get_fan_level(self, zone: int) -> int:
        """Return the current fan duty cycle percentage for the given zone."""
        validate_input_range(zone, "zone", 0, self.FANCTL_COUNT - 1)
        r = self._exec(["raw", "0x30", "0x70", "0x88", f"0x{zone:02x}"])
        return int(r.stdout, 16)

    def set_fan_mode(self, mode: int) -> None:
        """Set the IPMI fan mode."""
        if mode not in self.valid_fan_modes:
            raise ValueError(f"Invalid value: fan mode ({mode}).")
        self._exec(["raw", "0x30", "0x45", "0x01", f"0x{mode:02x}"])

    def set_fan_level(self, zone: int, level: int) -> None:
        """Set the fan duty cycle percentage for the given zone."""
        # X14 uses the percentage directly (0x00-0x64); manual mode must be enabled first (start()).
        validate_input_range(zone, "zone", 0, self.FANCTL_COUNT - 1)
        validate_input_range(level, "level", 0, 100)
        self._exec(["raw", "0x30", "0x70", "0x88", f"0x{zone:02x}", f"0x{level:02x}"])

    def set_multiple_fan_levels(self, zone_list: List[int], level: int) -> None:
        """Set the same fan duty cycle percentage for all given zones."""
        # X14 uses the percentage directly (0x00-0x64); manual mode must be enabled first (start()).
        for zone in zone_list:
            validate_input_range(zone, "zone", 0, self.FANCTL_COUNT - 1)
        validate_input_range(level, "level", 0, 100)
        for zone in zone_list:
            self._exec(["raw", "0x30", "0x70", "0x88", f"0x{zone:02x}", f"0x{level:02x}"])


# End.
